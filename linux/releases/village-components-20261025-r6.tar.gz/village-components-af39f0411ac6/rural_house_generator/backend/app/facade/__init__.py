"""Facade image processing primitives."""
