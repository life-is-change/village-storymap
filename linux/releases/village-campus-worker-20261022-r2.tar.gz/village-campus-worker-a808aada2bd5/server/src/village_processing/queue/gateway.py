import json
from pathlib import Path
import re

from village_processing.contracts import ArtifactSummary
from .models import QueuedRun


BUCKET = "geoprocessing-results"


def safe_message(message: str) -> str:
    text = re.sub(r"https?://\S+", "[remote service]", str(message))
    text = re.sub(r"(?i)\b[a-z]:\\[^\r\n,;]+", "[local path]", text)
    text = re.sub(r"(?<![\w:])/[^\s,;]+", "[local path]", text)
    text = re.sub(r"\beyJ[A-Za-z0-9_.-]{20,}\b", "[credential]", text)
    text = text.replace("Traceback (most recent call last):", "")
    return " ".join(text.split())[:300]


class SupabaseGateway:
    def __init__(self, client):
        self.client = client

    def claim(self, worker_id: str) -> QueuedRun | None:
        rows = self.client.rpc(
            "claim_next_geoprocessing_run", {"p_worker_id": worker_id}
        ).execute().data or []
        if not rows:
            return None
        return QueuedRun.from_row(dict(rows[0]))

    def renew(self, run_id: str, worker_id: str) -> None:
        self.client.rpc("renew_geoprocessing_lease", {
            "p_run_id": run_id, "p_worker_id": worker_id,
        }).execute()

    def _state(self, run_id: str, worker_id: str, status: str, **values) -> None:
        payload = {"p_run_id": run_id, "p_worker_id": worker_id, "p_status": status}
        payload.update(values)
        self.client.rpc("set_geoprocessing_run_state", payload).execute()

    def set_running(self, run_id: str, worker_id: str) -> None:
        self._state(run_id, worker_id, "running", p_stage="starting", p_progress=1)

    def set_stage(self, run_id: str, worker_id: str, stage: str, progress: int) -> None:
        self._state(run_id, worker_id, "running", p_stage=stage, p_progress=progress)

    def complete(self, run_id: str, worker_id: str, warnings: tuple[str, ...]) -> None:
        self._state(
            run_id, worker_id, "completed", p_stage="completed", p_progress=100,
            p_warnings=list(warnings),
        )

    def fail(self, run_id: str, worker_id: str, error_code: str, message: str) -> None:
        self._state(
            run_id, worker_id, "failed", p_error_code=error_code,
            p_error_message=safe_message(message),
        )

    def cancel(self, run_id: str, worker_id: str) -> None:
        self._state(run_id, worker_id, "canceled", p_stage="canceled")

    def is_cancel_requested(self, run_id: str) -> bool:
        result = self.client.table("geoprocessing_runs").select("status").eq("id", run_id).single().execute()
        return bool(result.data and result.data.get("status") == "cancel_requested")

    def upload_artifact(
        self, owner_id: str, run_id: str, worker_id: str, summary: ArtifactSummary
    ) -> str:
        storage_path = f"{owner_id}/{run_id}/{summary.path.name}"
        self.client.storage.from_(BUCKET).upload(
            storage_path,
            Path(summary.path).read_bytes(),
            {"content-type": "application/geo+json", "upsert": "true"},
        )
        try:
            source = json.loads(summary.source)
        except (TypeError, json.JSONDecodeError):
            source = {"description": safe_message(summary.source)}
        self.client.rpc("record_geoprocessing_artifact", {
            "p_run_id": run_id,
            "p_worker_id": worker_id,
            "p_artifact_type": summary.artifact_type,
            "p_storage_path": storage_path,
            "p_feature_count": summary.feature_count,
            "p_bbox": list(summary.bbox),
            "p_sha256": summary.sha256,
            "p_source": source,
            "p_warning_code": summary.warning_code,
        }).execute()
        return storage_path

    def heartbeat(self, worker_id: str, state: str, version: str) -> None:
        self.client.rpc("upsert_worker_heartbeat", {
            "p_worker_id": worker_id, "p_state": state, "p_version": version,
        }).execute()

    def list_published_village_ids(self) -> tuple[str, ...]:
        rows = self.client.table("villages").select("id").eq("status", "published").execute().data or []
        return tuple(str(row["id"]) for row in rows)

    def publish_source_status(
        self, village_id: str, ready: bool, code: str | None,
        worker_id: str, bounds: list[float] | None,
    ) -> None:
        self.client.rpc("upsert_geoprocessing_source_status", {
            "p_village_id": village_id,
            "p_ready": ready,
            "p_error_code": code,
            "p_worker_id": worker_id,
            "p_bounds": bounds,
        }).execute()
