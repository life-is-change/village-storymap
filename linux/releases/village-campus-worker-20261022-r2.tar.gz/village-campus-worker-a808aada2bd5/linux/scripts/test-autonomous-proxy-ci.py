#!/usr/bin/env python3
"""Disposable CI only: actual pinned nginx/Certbot, fixture certificates/upstreams.

This never requests a CA certificate, starts PostgreSQL or runs ML/provider jobs.
"""
import hashlib
import http.client
import json
import os
from pathlib import Path
import socket
import ssl
import subprocess
import tempfile
import time
import autonomous_tls as tls

ROOT=Path(__file__).resolve().parents[2]
NETWORK='village-autonomous-proxy-ci'
FRONT='village-autonomous-front-ci'
WEB='village-autonomous-proxy-ci'
UPSTREAM='village-autonomous-upstreams-ci'
LEGACY='village-autonomous-legacy-acme-ci'


def run(*args):
    try:return subprocess.run(list(args),check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=120).stdout
    except subprocess.SubprocessError:raise RuntimeError('DISPOSABLE_PROXY_PROCESS_FAILED') from None


def docker(*args):return run('docker','--context','default',*args)


def fixture_certificate(root,name):
    cert=root/(name+'.pem');key=root/(name+'.key')
    run('openssl','req','-x509','-newkey','rsa:2048','-sha256','-nodes','-days','1','-subj','/CN=disposable-ci-only',
        '-addext','subjectAltName=IP:'+tls.IP,'-keyout',str(key),'-out',str(cert))
    for path in (cert,key):path.chmod(0o600)
    return cert,key


def request(path,*,certificate=None):
    port=18443 if certificate else 18086
    connection=socket.create_connection(('127.0.0.1',port),timeout=5)
    secure=ssl.create_default_context(cafile=str(certificate)).wrap_socket(connection,server_hostname=tls.IP) if certificate else connection
    try:
        secure.sendall(('GET '+path+' HTTP/1.1\r\nHost: '+tls.IP+'\r\nConnection: close\r\n\r\n').encode())
        reply=http.client.HTTPResponse(secure);reply.begin();body=reply.read(32769)
        if len(body)>32768:raise ValueError('DISPOSABLE_RESPONSE_TOO_LARGE')
        fingerprint=hashlib.sha256(secure.getpeercert(binary_form=True)).hexdigest() if certificate else None
        return reply.status,body,fingerprint
    finally:secure.close()



def legacy_acme_permissions_fixture(root,image):
    from autonomous_bundle import load_script
    public=root/'legacy-web';public.mkdir(mode=0o755);public.chmod(0o755)
    (public/'index.html').write_text('legacy fixture');(public/'index.html').chmod(0o644)
    for folder in (public/'.well-known',public/'.well-known/acme-challenge'):folder.mkdir(mode=0o700);folder.chmod(0o700)
    config=root/'legacy-nginx.conf'
    config.write_text('user nginx; pid /tmp/nginx.pid; error_log /dev/stderr warn; events {} http { access_log off; client_body_temp_path /tmp/client; proxy_temp_path /tmp/proxy; fastcgi_temp_path /tmp/fastcgi; uwsgi_temp_path /tmp/uwsgi; scgi_temp_path /tmp/scgi; server { listen 8080; root /usr/share/nginx/html; '+tls.ACME_LOCATION+' location / { try_files $uri =404; } } }')
    config.chmod(0o644)
    docker('run','--detach','--pull=never','--name',LEGACY,'--network',FRONT,'--read-only','--cap-drop','ALL',
        '--cap-add','SETUID','--cap-add','SETGID','--cap-add','CHOWN','--security-opt','no-new-privileges:true','--memory','64m',
        '--tmpfs','/tmp:size=16m,mode=1777','--entrypoint','/usr/sbin/nginx','-p','127.0.0.1:18089:8080',
        '--mount',f'type=bind,source={public},target=/usr/share/nginx/html,readonly',
        '--mount',f'type=bind,source={config},target=/etc/nginx/nginx.conf,readonly',image,'-g','daemon off;')
    for attempt in range(50):
        connection=http.client.HTTPConnection('127.0.0.1',18089,timeout=2)
        try:
            connection.request('GET','/index.html');reply=connection.getresponse()
            if reply.status==200 and reply.read(256)==b'legacy fixture':break
        except OSError:pass
        finally:connection.close()
        time.sleep(.1)
    else:raise ValueError('LEGACY_ACME_FIXTURE_NOT_READY')
    previous=os.umask(0o077)
    try:load_script('prepare-ip-tls').verify_acme_webroot(public,port=18089)
    finally:os.umask(previous)
    print('LEGACY_ACME_PRIVATE_UMASK_DIFFERENT_UID_VERIFIED')


def main():
    if os.environ.get('GITHUB_ACTIONS')!='true' or os.environ.get('VILLAGE_TEST_PROXY_RUNTIME')!='1':
        raise SystemExit('DISPOSABLE_GITHUB_PROXY_RUNTIME_REQUIRED')
    if run('docker','--context','default','context','inspect','default','--format','{{.Endpoints.docker.Host}}').strip()!=b'unix:///var/run/docker.sock':
        raise SystemExit('DISPOSABLE_LOCAL_ENGINE_REQUIRED')
    nginx=json.loads((ROOT/'linux/nginx-runtime.json').read_text())
    certbot=json.loads((ROOT/'linux/certbot-runtime.json').read_text())
    for meta in (nginx,certbot):
        docker('pull',meta['image'])
        obj=json.loads(docker('image','inspect',meta['image']))[0]
        if (obj['Id'],obj['Os'],obj['Architecture'])!=(meta['image_id'],'linux','amd64'):raise ValueError('PINNED_CI_IMAGE_DIFFERS')
    if b'certbot 5.4.0' not in docker('run','--rm','--network','none',certbot['image'],'--version'):raise ValueError('CERTBOT_VERSION_DIFFERS')
    help_text=docker('run','--rm','--network','none',certbot['image'],'--help','all')
    if not all(flag in help_text for flag in (b'--ip-address',b'--preferred-profile',b'--webroot-path')):raise ValueError('IP_CERTBOT_FLAGS_UNSUPPORTED')
    with tempfile.TemporaryDirectory(prefix='village-proxy-ci-') as directory:
        root=Path(directory);root.chmod(0o700)
        for name in ('tls','web','acme'):(root/name).mkdir(mode=0o700)
        challenge=root/'acme/.well-known/acme-challenge';challenge.mkdir(parents=True);(challenge/'fixture').write_text('fixture-acme')
        (root/'web/index.html').write_text('autonomous fixture')
        (root/'web/deployment-config.js').write_text('fixture deployment')
        (root/'nginx.conf').write_text((ROOT/'linux/nginx.autonomous.conf').read_text())
        (root/'upstreams.conf').write_text('pid /tmp/nginx.pid; error_log /dev/stderr warn; events {} http { access_log off; client_body_temp_path /tmp/client; proxy_temp_path /tmp/proxy; fastcgi_temp_path /tmp/fastcgi; uwsgi_temp_path /tmp/uwsgi; scgi_temp_path /tmp/scgi; server { listen 8080; location / { default_type application/json; return 401 \'{"fixture":"api"}\'; } } server { listen 9999; location = /health { return 200 "fixture-auth"; } location / { return 401; } } }')
        first,first_key=fixture_certificate(root,'first');second,second_key=fixture_certificate(root,'second')
        tls.atomic_certificate(root/'tls',fullchain=first.read_bytes(),private_key=first_key.read_bytes(),reload=lambda:None)
        docker('network','create','--internal',NETWORK)
        docker('network','create',FRONT)
        try:
            common=['--detach','--pull=never','--user',f'{os.geteuid()}:{os.getegid()}',
                '--read-only','--cap-drop','ALL','--security-opt','no-new-privileges:true','--memory','64m','--tmpfs','/tmp:size=16m,mode=1777','--entrypoint','/usr/sbin/nginx']
            docker('run',*common,'--network',NETWORK,'--name',UPSTREAM,'--network-alias','api','--network-alias','auth',
                '--mount',f'type=bind,source={root}/upstreams.conf,target=/etc/nginx/nginx.conf,readonly',nginx['image_id'],'-g','daemon off;')
            mounts=[]
            for source,target in [('web','/srv/village-web'),('tls','/run/tls'),('acme','/srv/acme'),('nginx.conf','/etc/nginx/nginx.conf')]:
                mounts+=['--mount',f'type=bind,source={root/source},target={target},readonly']
            docker('run',*common,'--network',FRONT,'--network',NETWORK,'--name',WEB,'-p','127.0.0.1:18086:8080','-p','127.0.0.1:18443:8443',*mounts,nginx['image_id'],'-g','daemon off;')
            last_probe='not_attempted'
            for attempt in range(50):
                try:
                    reply=request('/',certificate=first)
                    last_probe='status='+str(reply[0])+' body='+repr(reply[1][:100])
                    if reply[:2]==(200,b'autonomous fixture'):break
                except (OSError,ssl.SSLError) as error:last_probe=type(error).__name__+': '+str(error)[:200]
                time.sleep(.1)
            else:
                print('FIXTURE_LAST_TLS_PROBE '+last_probe)
                # These containers contain synthetic upstreams/certificates
                # only. Capture startup diagnostics before the exact-name CI
                # cleanup; production operator code never prints logs.
                for name in (WEB,UPSTREAM):
                    result=subprocess.run(['docker','--context','default','logs','--tail','15',name],capture_output=True,text=True,timeout=10)
                    print('FIXTURE_CONTAINER_STARTUP '+name+' '+(result.stdout+result.stderr)[-3000:])
                result=subprocess.run(['docker','--context','default','exec',WEB,'wget','-qO-','http://127.0.0.1:8080/.well-known/acme-challenge/fixture'],capture_output=True,text=True,timeout=10)
                print('FIXTURE_INSIDE_ACME '+str(result.returncode)+' '+result.stdout[:100])
                raise ValueError('DISPOSABLE_PROXY_NOT_READY')
            assert request('/.well-known/acme-challenge/fixture')[:2]==(200,b'fixture-acme')
            assert request('/')[0]==308
            for path,status in [('/auth/v1/health',200),('/auth/v1/admin/users',404),('/api/v1/me',401),('/.git/config',403),('/business-api/package.json',404)]:
                assert request(path,certificate=first)[0]==status,path
            def reload():
                docker('exec',WEB,'/usr/sbin/nginx','-t');docker('exec',WEB,'/usr/sbin/nginx','-s','reload')
            tls.atomic_certificate(root/'tls',fullchain=second.read_bytes(),private_key=second_key.read_bytes(),reload=reload)
            for attempt in range(50):
                try:
                    if request('/',certificate=second)[0]==200:break
                except ssl.SSLError:pass
                time.sleep(.1)
            else:raise ValueError('DISPOSABLE_TLS_ROTATION_NOT_VISIBLE')
            legacy_acme_permissions_fixture(root,nginx['image_id'])
            print('AUTONOMOUS_PROXY_CERTBOT_FIXTURE_VERIFIED_NOT_PUBLIC_CA_OR_DEPLOYMENT')
        finally:
            # Exact CI-only names on a disposable runner; no production paths.
            for name in (LEGACY,WEB,UPSTREAM):subprocess.run(['docker','--context','default','rm','--force',name],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            subprocess.run(['docker','--context','default','network','rm',NETWORK],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            subprocess.run(['docker','--context','default','network','rm',FRONT],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)


if __name__=='__main__':main()
